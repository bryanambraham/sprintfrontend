import CalculatorCargo from '@/components/calculator-cargo'
import CargoSearch from '@/components/ship-search'
import React from 'react'

const page = () => {
  return (
    <div>
        <CalculatorCargo/>
    </div>
  )
}

export default page
